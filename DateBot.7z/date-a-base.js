//Add each dateID to this array. The AI will loop through this array and choose the date that has a specific match. The array must always include a 0 and have an extra number at the end.
let dateIdArray = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18];

let goOutForIceCream = {
    description: 'go out for ice cream.',
    budget: 5,
    season: 'Any',
    weather: 'Any',
    latestTime: 'Any',
    locations: ["Coldstone, BYU Creamery, Brookers, Mcdonalds."],
    dateId: 1,
    displayIceCreamDate() {
        perfectDate = "Your perfect date is to " + goOutForIceCream.description + "<br>" + " The budget is $" + goOutForIceCream.budget + "."
            + "</br>" + "Locations include: " + goOutForIceCream.locations;
        } 
}; 
let eatMexticanFood = {
    description: 'go out to eat Mexican food.',
    budget: 20,
    season: 'Any',
    weather: 'Any',
    latestTime: 2100,
    locations: ["Mi Ranchito, Pacos Tacos, Cafe Rio."],
    dateId: 2,
    displayEatMexicanFoodDate() {
        perfectDate = "Your perfect date is to " + eatMexticanFood.description + "<br>" + " The budget is $" + eatMexticanFood.budget + "."
            + "</br>" + "Locations include: " + eatMexticanFood.locations;
        } 
};
let seeAMovie = {
    description: 'go see a movie.',
    budget: 12,
    season: 'Any',
    weather: 'Any',
    latestTime: 2100,
    locations: ["Cinemark, Megaplex, drive-in, Sticky-Shoe."],
    dateId: 3,
    displaySeeAMovieDate() {
        perfectDate = "Your perfect date is to " + seeAMovie.description + "<br>" + " The budget is $" + seeAMovie.budget + "."
            + "</br>" + "Locations include: " + seeAMovie.locations;
        } 
};
let goSledding = {
    description: 'go sledding.',
    budget: 0,
    season: 'Winter',
    weather: 'Any',
    latestTime: 2000,
    locations: ["Any snow-covered hill."],
    dateId: 4,
    displayGoSleddingDate() {
        perfectDate = "Your perfect date is to " + goSledding.description + "<br>" + " The budget is $" + goSledding.budget + "."
            + "</br>" + "Locations include: " + goSledding.locations;
        } 
};
let hauntedHouse = {
    description: 'go to a haunted house.',
    budget: 50,
    season: 'Fall',
    month: 'October',
    weather: 'Any',
    latestTime: 2200,
    locations: ["Haunted Forest, Castle of Chaos, Nightmare on 13th."],
    dateId: 5,
    displayhauntedHouseDate() {
        perfectDate = "Your perfect date is to " + hauntedHouse.description + "<br>" + " The budget is $" + hauntedHouse.budget + "."
            + "</br>" + "Locations include: " + hauntedHouse.locations;
        } 
};
let hotChocolate = {
    description: 'go to get hot chocolate.',
    budget: 5,
    season: 'Any',
    month: 'Any',
    weather: 'Cold',
    latestTime: 2200,
    locations: ["Starbucks, Maverick"],
    dateId: 6,
    displayHotChocolateDate() {
        perfectDate = "Your perfect date is to " + hotChocolate.description + "<br>" + " The budget is $" + hotChocolate.budget + "."
            + "</br>" + "Locations include: " + hotChocolate.locations;
        } 
};
let goSwimming = {
    description: 'go swimming.',
    budget: 10,
    season: 'Summer',
    month: 'Any',
    weather: 'Any',
    latestTime: 2100,
    locations: ["Provo Rec, Lehi Rec, American Fork Rec, Lindon Aquatics Center."],
    dateId: 7,
    displayGoSwimmingDate() {
        perfectDate = "Your perfect date is to " + goSwimming.description + "<br>" + " The budget is $" + goSwimming.budget + "."
            + "</br>" + "Locations include: " + goSwimming.locations;
        } 
};
let cornMaze = {
    description: 'go to a corn maze.',
    budget: 20,
    season: 'Fall',
    month: 'Any',
    weather: 'Any',
    latestTime: 2100,
    locations: ["CornBelly's"],
    dateId: 8,
    displayCornMazeDate() {
        perfectDate = "Your perfect date is to " + cornMaze.description + "<br>" + " The budget is $" + cornMaze.budget + "."
            + "</br>" + "Locations include: " + cornMaze.locations;
        } 
};
let seeFallLeaves = {
    description: 'See the Fall leaves and their beautiful colors.',
    budget: 0,
    season: 'Fall',
    month: 'Any',
    weather: 'Any',
    latestTime: 2000,
    locations: ["American Fork Canyon, Provo Canyon, the Alpine Loop."],
    dateId: 9,
    displayFallLeavesDate() {
        perfectDate = "Your perfect date is to " + seeFallLeaves.description + "<br>" + " The budget is $" + seeFallLeaves.budget + "."
            + "</br>" + "Locations include: " + seeFallLeaves.locations;
        } 
};
let haveAPicnic = {
    description: 'have a picnic.',
    budget: 0,
    season: 'Summer', //Or spring
    month: 'Any',
    weather: 'Any', //Not rainy.
    latestTime: 2000,
    locations: ["Highland Glenn Park, Provo Canyon, the park next door."],
    dateId: 10,
    displayHaveAPicnicDate() {
        perfectDate = "Your perfect date is to " + haveAPicnic.description + "<br>" + " The budget is $" + haveAPicnic.budget + "."
            + "</br>" + "Locations include: " + haveAPicnic.locations;
        } 
};
let goOnAHike = {
    description: 'go on a hike.',
    budget: 0,
    season: 'Summer', //Or Spring or Fall.
    month: 'Any',
    weather: 'Any', //Not rainy.
    latestTime: 2000,
    locations: ["BattleCreek Falls, HorseTail Falls."],
    dateId: 11,
    displayGoOnAHikeDate() {
        perfectDate = "Your perfect date is to " + goOnAHike.description + "<br>" + " The budget is $" + goOnAHike.budget + "."
            + "</br>" + "Locations include: " + goOnAHike.locations;
        } 
};
let secretSanta = {
    description: 'have a secret Santa gift exchange/competition with some friends.',
    budget: 5,
    season: 'Winter', //or any.
    month: 'December',
    weather: 'Any', 
    latestTime: 2100,
    locations: ["Any mall or store."],
    dateId: 12,
    displaySecretSantaDate() {
        perfectDate = "Your perfect date is to " + secretSanta.description + "<br>" + " The budget is $" + secretSanta.budget + "."
            + "</br>" + "Locations include: " + secretSanta.locations;
        } 
};
let eatAtAFoodTruck = {
    description: 'eat at a food truck.',
    budget: 10,
    season: 'Any', //not winter.
    month: 'Any',
    weather: 'Any', //not raining.
    latestTime: 2000,
    locations: ["Food trucks in your area."],
    dateId: 13,
    displayFoodTruckDate() {
        perfectDate = "Your perfect date is to " + eatAtAFoodTruck.description + "<br>" + " The budget is $" + eatAtAFoodTruck.budget + "."
            + "</br>" + "Locations include: " + eatAtAFoodTruck.locations;
        } 
};
let makeIceCreamSandwiches = {
    description: 'make ice cream sandwiches using cookies and your favorite flavor of ice cream.',
    budget: 10,
    season: 'Any', // Summer or spring
    month: 'Any',
    weather: 'Any', //not cold or snowy
    latestTime: 2200,
    locations: ["Your house."],
    dateId: 14,
    displayMakeIceCreamSandwichesDate() {
        perfectDate = "Your perfect date is to " + makeIceCreamSandwiches.description + "<br>" + " The budget is $" + makeIceCreamSandwiches.budget + "."
            + "</br>" + "Locations include: " + makeIceCreamSandwiches.locations;
        } 
};
let fingerPaint = {
    description: 'buy some finger paints, get a white tarp, and finger paint with each other!',
    budget: 10,
    season: 'Any',
    month: 'Any',
    weather: 'Any',
    latestTime: 2200,
    locations: ["Your house."],
    dateId: 15,
    displayFingerPaintDate() {
        perfectDate = "Your perfect date is to " + fingerPaint.description + "<br>" + " The budget is $" + fingerPaint.budget + "."
            + "</br>" + "Locations include: " + fingerPaint.locations;
        } 
};
let milkshakes = {
    description: 'go and get some milkshakes!',
    budget: 8,
    season: 'Any', 
    month: 'Any',  
    weather: 'Any', 
    latestTime: 2200,
    locations: ["Sonic, Purple Turtle, Five Guys, jcw's, Mcdonalds."],
    dateId: 16,
    displayMilkShakeDate() {
        perfectDate = "Your perfect date is to " + milkshakes.description + "<br>" + " The budget is $" + milkshakes.budget + "."
            + "</br>" + "Locations include: " + milkshakes.locations;
        } 
};
let movieNight = {
    description: 'have a movie night at home. Get some popcorn while you\'re at it.',
    budget: 0,
    season: 'Any', 
    month: 'Any',  
    weather: 'Any', 
    latestTime: 2200,
    locations: ["You're house."],
    dateId: 17,
    displayMovieNightDate() {
        perfectDate = "Your perfect date is to " + movieNight.description + "<br>" + " The budget is $" + movieNight.budget + "."
            + "</br>" + "Locations include: " + movieNight.locations;
        } 
};