  
  //These functions determine the season.
  let dateSeason = "Any";
  function winterDateSeason() {
      dateSeason = "Winter";
  }
  function springDateSeason() {
      dateSeason = "Spring";
  }
  function summerDateSeason() {
      dateSeason = "Summer";
  }
  function fallDateSeason() {
      dateSeason = "Fall";
  }
  function anyDateSeason() {
      dateSeason = "Any";
  }
  

  //These functions determine the weather. 
  let dateWeather = "Any"; 
  function sunnyDateWeather() {
      dateWeather = "Sunny";
  }
  function cloudyDateWeather() {
      dateWeather = "Cloudy";
  }
  function rainyDateWeather() {
      dateWeather = "Rainy";
  }
  function coldDateWeather() {
      dateWeather = "Cold";
  }
  function snowyDateWeather() {
      dateWeather = "Snowy";
  }
  function anyDateWeather() {
      dateWeather = "Any";
  }

  //These functions determine the time. Include another variable that gives the actual time displayed. For example, 0700 would be 7AM.
  let dateTime = "Any";
  let timedisplayed = "Any";
  function sevenAm() {
      dateTime = 0700;
      timedisplayed = "7Am";
  }
  function eightAm() {
    dateTime = 0800;
    timedisplayed = "8Am";
  }
  function nineAm() {
    dateTime = 0900;
    timedisplayed = "9AM";
  }
  function tenAm() {
    dateTime = 1000;
    timedisplayed = "10AM";
  }
  function elevenAm() {
    dateTime = 1100;
    timedisplayed = "11AM";
  }
  function twelvePm() {
    dateTime = 1200;
    timedisplayed = "12PM";
  }
  function onePm() {
    dateTime = 1300;
    timedisplayed = "1PM";
  }
  function twoPm() {
    dateTime = 1400;
    timedisplayed = "2PM";
  }
  function threePm() {
    dateTime = 1500;
    timedisplayed = "3PM";
  }
  function fourPm() {
    dateTime = 1600;
    timedisplayed = "4PM";
  }
  function fivePm() {
    dateTime = 1700;
    timedisplayed = "5PM";
  }
  function sixPm() {
    dateTime = 1800;
    timedisplayed = "6PM";
  }
  function sevenPm() {
    dateTime = 1900;
    timedisplayed = "7PM";
  }
  function eightPm() {
    dateTime = 2000;
    timedisplayed = "8PM";
  }
  function ninePm() {
    dateTime = 2100;
    timedisplayed = "9PM";
  }
  function tenPm() {
    dateTime = 2200;
    timedisplayed = "10PM";
  }
  function anyTime() {
    dateTime = "Any";
    timedisplayed = "Any";
  }
  
  //These functions determine the month.
  let dateMonth = "Any";
  function january() {
    dateMonth = "January";
  }
  function february() {
    dateMonth = "February";
  }
  function march() {
    dateMonth = "March";
  }
  function april() {
    dateMonth = "April";
  }
  function may() {
    dateMonth = "May";
  }
  function june() {
    dateMonth = "June";
  }
  function july() {
    dateMonth = "July";
  }
  function august() {
    dateMonth = "August";
  }
  function september() {
    dateMonth = "September";
  }
  function october() {
    dateMonth = "October";
  }
  function november() {
    dateMonth = "November";
  }
  function december() {
    dateMonth = "December";
  }
  function anyMonth() {
    dateMonth = "Any";
  }

  //Declare userBudget to give it a global scope.
  let userBudget;
  //This function will display the date criteria to the user.
  function displayCriteria() {
    userBudget = parseFloat(document.getElementById("budget").value);
    let output = "Budget: $" + userBudget + " or less." + "<br>" + "Season: " + dateSeason + "<br>" + "Weather " + dateWeather + "<br>" + "Time: " + timedisplayed + "<br>" + "Month: " + dateMonth;
    document.getElementById('dateCriteria').innerHTML = output;
}

  let perfectDate; 

  function displayDateWithArray() {
    userBudget = parseFloat(document.getElementById("budget").value);
    //Chooses a random number and then uses a for loop to loop through an array. With each number chosen in the array, it checks to see if the criteria is met. If it is, it displays that
    //date to the screen. If not, it moves onto the next.

    /*Pulls a random number. Make sure to update the variable max as you add dates to dateDateabase.js. I believe max has to be one more than the number of objects in dateDatabase.js.
    * Don't include the criteria in the if statement if the object's budget, season, weather, or time is "Any".
    */
    let min = 1;
    let max = dateIdArray.length;
    let randomNumber = min + Math.floor(Math.random() * (max-min));
    //let randomNumber = secretSanta.dateId;

    for (i=randomNumber; i<=dateIdArray.length; i++) {
      if (randomNumber == goOutForIceCream.dateId && userBudget >= goOutForIceCream.budget) {
        goOutForIceCream.displayIceCreamDate();
        break;
      } else if (userBudget >= eatMexticanFood.budget && (dateTime <= eatMexticanFood.latestTime || dateTime == "Any") && randomNumber == eatMexticanFood.dateId) {
        eatMexticanFood.displayEatMexicanFoodDate();
        break; 
      } else if (userBudget >= seeAMovie.budget && (dateTime <= seeAMovie.latestTime || dateTime == "Any") && randomNumber == seeAMovie.dateId) {
        seeAMovie.displaySeeAMovieDate();
        break;
      } else if ((dateTime <= goSledding.latestTime || dateTime == "Any") && randomNumber == goSledding.dateId && dateSeason == goSledding.season && dateWeather != "Rainy") {
        goSledding.displayGoSleddingDate();
        break;
      } else if (userBudget >= hauntedHouse.budget && (dateTime <= hauntedHouse.latestTime || dateTime == "Any") && randomNumber == hauntedHouse.dateId && dateSeason == hauntedHouse.season && dateMonth == hauntedHouse.month) {
        hauntedHouse.displayhauntedHouseDate();
        break;
      } else if (userBudget >= hotChocolate.budget && (dateTime <= hotChocolate.latestTime || dateTime == "Any") && randomNumber == hotChocolate.dateId && dateWeather == hotChocolate.weather) {
        hotChocolate.displayHotChocolateDate();
        break;
      } else if (userBudget >= goSwimming.budget && (dateTime <= goSwimming.latestTime || dateTime == "Any") && randomNumber == goSwimming.dateId && dateSeason == goSwimming.season) {
        goSwimming.displayGoSwimmingDate();
        break;
      } else if (userBudget >= cornMaze.budget && (dateTime <= cornMaze.latestTime || dateTime == "Any") && randomNumber == cornMaze.dateId && dateSeason == cornMaze.season && dateWeather != "Rainy") {
        cornMaze.displayCornMazeDate();
        break;
      } else if (userBudget >= seeFallLeaves.budget && (dateTime <= seeFallLeaves.latestTime || dateTime == "Any") && randomNumber == seeFallLeaves.dateId && dateSeason == seeFallLeaves.season && (dateMonth == "September" || dateMonth == "November")) {
        seeFallLeaves.displayFallLeavesDate();
        break;
      } else if (userBudget >= haveAPicnic.budget && (dateTime <= haveAPicnic.latestTime || dateTime == "Any") && randomNumber == haveAPicnic.dateId && (dateSeason == haveAPicnic.season || dateSeason == "Spring") && dateWeather != "Rainy") {
        haveAPicnic.displayHaveAPicnicDate();
      } else if (userBudget >= goOnAHike.budget && (dateTime <= goOnAHike.latestTime || dateTime == "Any") && randomNumber == goOnAHike.dateId && (dateSeason == "Summer" || dateSeason == "Fall" || dateSeason == "Spring") && dateWeather != "Rainy") {
        goOnAHike.displayGoOnAHikeDate();
      } else if (userBudget >= secretSanta.budget && (dateTime <= secretSanta.latestTime || dateTime == "Any") && randomNumber == secretSanta.dateId && dateMonth == "December") {
        secretSanta.displaySecretSantaDate();
      } else if (userBudget >= eatAtAFoodTruck.budget && (dateTime <= eatAtAFoodTruck.latestTime || dateTime == "Any") && randomNumber == eatAtAFoodTruck.dateId && dateWeather != 'Rainy' && dateSeason != 'Winter') {
        eatAtAFoodTruck.displayFoodTruckDate();
      } else if (userBudget >= makeIceCreamSandwiches.budget && (dateTime <= makeIceCreamSandwiches.latestTime || dateTime == "Any") && randomNumber == makeIceCreamSandwiches.dateId && (dateSeason == 'Summer' || dateSeason == 'Spring' || dateSeason == "Any") && (dateWeather != "Cold" || dateWeather || "Snowy")) {
        makeIceCreamSandwiches.displayMakeIceCreamSandwichesDate();
      } else if (userBudget >= fingerPaint.budget && (dateTime <= fingerPaint.dateId || dateTime == "Any") && randomNumber == fingerPaint.dateId) {
        fingerPaint.displayFingerPaintDate();
      } else if (userBudget >= milkshakes.budget && (dateTime <= milkshakes.dateId || dateTime == "Any") && randomNumber == milkshakes.dateId) {
        milkshakes.displayMilkShakeDate();
      } else if (userBudget >= movieNight.budget && (dateTime <= movieNight.dateId || dateTime == "Any") && randomNumber == movieNight.dateId) {
        movieNight.displayMovieNightDate();
      }
    }
    //alert(randomNumber);

    // Displays the variable in the div that has the id specified below.
    document.getElementById('perfectDate').innerHTML = perfectDate;
}